#!/bin/bash

#cd HFU_LV/K8s_no_PAL
./K8s_with_PAL_TestApp.py
