#!/bin/bash

./workload_generator.sh && pkill -f python3


