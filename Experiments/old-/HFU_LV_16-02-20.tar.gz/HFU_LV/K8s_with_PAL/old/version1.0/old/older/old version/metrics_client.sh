#!/bin/bash

#cd HFU_LV/K8s_no_PAL
#xterm -e dana K8s_no_PAL_App.o
xterm -e ./K8s_with_PAL_GetMetrics.py 
