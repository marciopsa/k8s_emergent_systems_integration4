#!/bin/bash

#cd HFU_LV/K8s_no_PAL
./K8s_no_PAL_TestApp.py 
